-- --------               << aula1exer2 >>              ------------ --
--                                                                   --
--                    SCRIPT DE EXCLUSAO (DDL)                       --
--                                                                   --
-- Data Criacao ..........: 21/08/2019                               --
-- Autor(es) .............: Max Henrique Barbosa                     --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2                               --
--                                                                   --
-- Data Ultima Alteracao ..: 19/08/2019                              --
--    + Deleta as tabelas da base de dados                           --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 9 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

DROP TABLE if exists inclui;
DROP TABLE if exists PRODUTO;
DROP TABLE if exists AREA;
DROP TABLE if exists faz;
DROP TABLE if exists VENDA;
DROP TABLE if exists telefone;
DROP TABLE if exists EMPREGADO;
DROP TABLE if exists GERENTE;
DROP TABLE if exists PESSOA;