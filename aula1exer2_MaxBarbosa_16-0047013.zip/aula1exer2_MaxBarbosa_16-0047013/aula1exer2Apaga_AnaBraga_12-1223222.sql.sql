-- --------               << aula1exer2 >>              ------------ --
--                                                                   --
--                    SCRIPT DE EXCLUSAO (DDL)                       --
--                                                                   --
-- Data Criacao ..........: 19/08/2019                               --
-- Autor(es) .............: Max Henrique Barbosa                     --
-- Banco de Dados ........: MySQL                                    --
-- Base de Dados(nome) ...: aula1exer2                               --
--                                                                   --
-- Data Ultima Alteracao ..: 19/08/2019                              --
--    + Deleta as tabelas da base de dados                           --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 7 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

DROP TABLE if exists supervisiona;
DROP TABLE if exists vende;
DROP TABLE if exists FUNCIONARIO;
DROP TABLE if exists PRODUTO;
DROP TABLE if exists EMPREGADO;
DROP TABLE if exists TELEFONE;
DROP TABLE if exists GERENTE;